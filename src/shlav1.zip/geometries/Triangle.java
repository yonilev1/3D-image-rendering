package geometries;

/**
 * Represents a triangle in three-dimensional space.
 */
public class Triangle extends Polygon {
    
}
